import logo from './logo.svg';
import './App.css';
import List from './List';
import data from './data'
import { useState } from 'react';

function App() {
  //create state variable to access the data object in it
  const [people, setPeople] = useState(data);
  return (
    <div className="App">
                <div className="container">
                <div className="row align-items-center height-100">
                    <div className="col-3">
                    </div>
                    <div className="col-6">
                        <div className="card">
                        <h3>{people.length} Birthdays today!!</h3>
                        <List people={people}/>
                        <button className="btn" onClick={() => setPeople([])}>Clear All</button>
                        </div>
                    </div>
                    <div className="col-3">
                    </div>
                </div>
            </div>
    </div>
  );
}

export default App;
 