import React from 'react';


function List({people}){
return(
    <>
    {people.map((person) => 
    <div className="media text-muted pt-3">
    <img src={person.src} className="mr-2 rounded" />
          <p className="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
            <strong className="d-block text-gray-dark name">{person.name}</strong>
            <strong>Hey!! you became {person.age} years old !!!</strong>{person.msg}
          </p>
        </div>
    )}
        </>
);
}

export default List;