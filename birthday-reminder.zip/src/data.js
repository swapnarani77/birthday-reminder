export default [
{
    id: 1,
    name: "Swapna",
    src: "https://www.w3schools.com/howto/img_avatar2.png",
    msg: 'Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    age: 25
},
{
    id: 2,
    name: "Bichitra",
    src: "https://www.w3schools.com/howto/img_avatar2.png",
    msg: 'Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    age: 26
},
{
    id: 3,
    name: "Salu",
    src: "https://www.w3schools.com/howto/img_avatar2.png",
    msg: 'Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    age: 27
},
{
    id: 4,
    name: "Abhishek",
    src: "https://www.w3schools.com/howto/img_avatar2.png",
    msg: 'Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    age: 26
}
];